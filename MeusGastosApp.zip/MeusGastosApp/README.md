# Atividade Continuada 3 - AC 

Aplicativo mobile simples e eficiente para gerenciamento de gastos pessoais. 
Desenvolvido com **React Native** e **TypeScript**

## 🛠️ Tecnologias Usadas

**React Hooks:** Gerenciamento de estado local utilizando `useState`
**FlatList:** Renderização de listas de alta performance
**KeyboardAvoidingView** Ajuste inteligente de layout para teclado mobile
**StyleSheet:** Troca de telas otimizada via estado local

# Andre de Queiroz Cenaque RA:86717 
# Marina Duarte Cabral RA: 94306 ---<br>

## Get started

