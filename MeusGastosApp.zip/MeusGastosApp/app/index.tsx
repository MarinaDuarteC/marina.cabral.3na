import * as React from 'react'
import {
	FlatList,
	KeyboardAvoidingView,
	Platform,
	SafeAreaView,
	StyleSheet,
	Text,
	TextInput,
	TouchableOpacity,
	View,
} from 'react-native'

// Simple two-screen app using local state for navigation so no extra deps are required.

interface Expense {
	id: string
	description: string
	value: number
}

export default function App() {
	const [screen, setScreen] = React.useState<'list' | 'form'>('list')
	const [expenses, setExpenses] = React.useState<Expense[]>([
		{ id: String(Date.now()), description: 'Café', value: 4.5 },
		{ id: String(Date.now() + 1), description: 'Transporte', value: 7.2 },
	])

	function handleDelete(id: string) {
		setExpenses(prev => prev.filter(e => e.id !== id))
	}

	function handleAdd(expense: { description: string; value: number }) {
		setExpenses(prev => [{ ...expense, id: String(Date.now()) }, ...prev])
	}

	return (
		<SafeAreaView style={styles.container}>
			{screen === 'list' ? (
				<ExpensesList
					expenses={expenses}
					onDelete={handleDelete}
					onGoToForm={() => setScreen('form')}
				/>
			) : (
				<ExpenseForm
					onCancel={() => setScreen('list')}
					onSave={expense => {
						handleAdd(expense)
						setScreen('list')
					}}
				/>
			)}
		</SafeAreaView>
	)
}

type ExpensesListProps = {
	expenses: Expense[]
	onDelete: (id: string) => void
	onGoToForm: () => void
}

function ExpensesList({ expenses, onDelete, onGoToForm }: ExpensesListProps) {
	const total = expenses.reduce((s: number, e: Expense) => s + Number(e.value || 0), 0)

	return (
		<View style={styles.screen}>
			<View style={styles.header}>
				<Text style={styles.title}>Meus Gastos</Text>
				<Text style={styles.total}>Total: R$ {total.toFixed(2)}</Text>
			</View>

			<FlatList
				data={expenses}
				keyExtractor={item => item.id}
				ListEmptyComponent={() => (
					<Text style={styles.empty}>Nenhum gasto registrado ainda.</Text>
				)}
				renderItem={({ item }) => (
					<View style={styles.item}>
						<View style={{ flex: 1 }}>
							<Text style={styles.itemDesc}>{item.description}</Text>
							<Text style={styles.itemValue}>R$ {Number(item.value).toFixed(2)}</Text>
						</View>
						<TouchableOpacity
							style={styles.deleteButton}
							onPress={() => onDelete(item.id)}
						>
							<Text style={styles.deleteText}>Excluir</Text>
						</TouchableOpacity>
					</View>
				)}
			/>

			<TouchableOpacity style={styles.addButton} onPress={onGoToForm}>
				<Text style={styles.addButtonText}>+ Novo gasto</Text>
			</TouchableOpacity>
		</View>
	)
}

type ExpenseFormProps = {
	onSave: (expense: { description: string; value: number }) => void
	onCancel: () => void
}

function ExpenseForm({ onSave, onCancel }: ExpenseFormProps) {
	const [description, setDescription] = React.useState('')
	const [valueText, setValueText] = React.useState('')
	const [errors, setErrors] = React.useState({ description: '', value: '' })

	function handleSubmit() {
		const trimmed = description.trim()
		const parsed = parseFloat(valueText.replace(',', '.'))
		const newErrors = { description: '', value: '' }

		if (!trimmed) newErrors.description = 'Descrição é obrigatória.'
		if (Number.isNaN(parsed) || parsed <= 0) newErrors.value = 'Informe um valor maior que zero.'

		setErrors(newErrors)

		if (!newErrors.description && !newErrors.value) {
			onSave({ description: trimmed, value: parsed })
		}
	}

	return (
		<KeyboardAvoidingView
			style={styles.screen}
			behavior={Platform.OS === 'ios' ? 'padding' : undefined}
		>
			<Text style={styles.formTitle}>Adicionar gasto</Text>

			<View style={styles.field}>
				<Text style={styles.label}>Descrição</Text>
				<TextInput
					value={description}
					onChangeText={setDescription}
					placeholder="Ex: Almoço"
					style={styles.input}
				/>
				{!!errors.description && <Text style={styles.error}>{errors.description}</Text>}
			</View>

			<View style={styles.field}>
				<Text style={styles.label}>Valor (R$)</Text>
				<TextInput
					value={valueText}
					onChangeText={setValueText}
					placeholder="Ex: 12.50"
					keyboardType="numeric"
					style={styles.input}
				/>
				{!!errors.value && <Text style={styles.error}>{errors.value}</Text>}
			</View>

			<View style={styles.formButtons}>
				<TouchableOpacity style={[styles.actionButton, styles.cancel]} onPress={onCancel}>
					<Text style={styles.actionText}>Cancelar</Text>
				</TouchableOpacity>

				<TouchableOpacity style={[styles.actionButton, styles.save]} onPress={handleSubmit}>
					<Text style={[styles.actionText, { color: '#fff' }]}>Salvar</Text>
				</TouchableOpacity>
			</View>
		</KeyboardAvoidingView>
	)
}

const styles = StyleSheet.create({
	container: { flex: 1, backgroundColor: '#5c5c5cff' },
	screen: { flex: 1, padding: 16 },
	header: { marginBottom: 12 },
	title: { fontSize: 24, fontWeight: '700' },
	total: { fontSize: 16, marginTop: 6, color: '#fff' },
	empty: { textAlign: 'center', marginTop: 40, color: '#666' },
	item: {
		flexDirection: 'row',
		alignItems: 'center',
		padding: 12,
		backgroundColor: '#fff',
		borderRadius: 8,
		marginBottom: 8,
		shadowColor: '#000',
		shadowOpacity: 0.03,
		shadowRadius: 4,
		elevation: 1,
	},
	itemDesc: { fontSize: 16, fontWeight: '600' },
	itemValue: { color: '#444', marginTop: 4 },
	deleteButton: {
		paddingVertical: 6,
		paddingHorizontal: 12,
		backgroundColor: '#ffecec',
		borderRadius: 6,
		marginLeft: 12,
	},
	deleteText: { color: '#cc0000' },
	addButton: {
		marginTop: 12,
		padding: 14,
		backgroundColor: '#0066cc',
		borderRadius: 8,
		alignItems: 'center',
	},
	addButtonText: { color: '#fff', fontWeight: '700' },

	formTitle: { fontSize: 20, fontWeight: '700', marginBottom: 12 },
	field: { marginBottom: 12 },
	label: { marginBottom: 6, color: '#fff' },
	input: {
		backgroundColor: '#fff',
		padding: 10,
		borderRadius: 6,
		borderWidth: 1,
		borderColor: '#e6e6e6',
	},
	error: { color: '#cc0000', marginTop: 6 },
	formButtons: { flexDirection: 'row', justifyContent: 'space-between', marginTop: 18 },
	actionButton: { flex: 1, padding: 12, borderRadius: 8, alignItems: 'center' },
	cancel: { backgroundColor: '#efefef', marginRight: 8 },
	save: { backgroundColor: '#007aff', marginLeft: 8 },
	actionText: { color: '#333', fontWeight: '700' },
})